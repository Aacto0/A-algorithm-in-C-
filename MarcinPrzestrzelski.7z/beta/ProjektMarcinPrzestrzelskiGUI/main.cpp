/**
  * \mainpage
  * \author Marcin Przestrzelski
  * \date 2021.06.09
  * \version 1.0
  * \par Kontakt:
  * \a 01161969@pw.edu.pl
*/

/**
 * \file Agwiazda.h
 * \brief Plik nagłówkowy z funkcjami i strukturami do rozwiązania problemu najkrótszej ścieżki na mapie za pomocą algorytmu A gwiazda.
 */

/**
 * \file mainwindow.cpp
 * \brief Plik nagłówkowy z funkcjami i strukturami do obsługi interfejsu okienkowego.
 */

#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
