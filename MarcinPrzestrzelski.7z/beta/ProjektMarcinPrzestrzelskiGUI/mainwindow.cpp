#include "mainwindow.h"
#include "ui_mainwindow.h"

daneMapy dane_mapy;
string nazwa_pliku;
char* mapa;

int x_start,x_cel,y_start,y_cel;

Wezel2D start;
Wezel2D cel;

int i_start;
int i_cel;
double *G;
int *P;



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->label_blad_Sciezka_do_zapisu_pliku->setEnabled(1);
    ui->label_blad_Sciezka_do_pliku_z_mapa->setEnabled(1);
    ui->label_blad_x_poczatkowy->setEnabled(1);
    ui->label_blad_x_koncowy->setEnabled(1);
    ui->label_blad_y_poczatkowy->setEnabled(1);
    ui->label_blad_y_koncowy->setEnabled(1);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pB_Zaladuj_mape_clicked()
{

        if(importMapy(ui->LE_adres_mapy_odczytu->text().toStdString(),mapa,dane_mapy)){
            ui->label_blad_Sciezka_do_pliku_z_mapa->setEnabled(0);

            ui->label_Udalo_sie_zaladowac_mape->setEnabled(1);
            ui->label_Zaladowano_mape_z->setEnabled(1);
            ui->label_pilik_z_ktorego_pobrano->setEnabled(1);
            ui->label_pilik_z_ktorego_pobrano->setText(ui->LE_adres_mapy_odczytu->text());
        }
        else{
            ui->label_blad_Sciezka_do_pliku_z_mapa->setEnabled(1);

            ui->label_Udalo_sie_zaladowac_mape->setEnabled(0);
            ui->label_Zaladowano_mape_z->setEnabled(0);
            ui->label_pilik_z_ktorego_pobrano->setEnabled(0);
            ui->label_pilik_z_ktorego_pobrano->setText("-");
        }

}

void MainWindow::on_pB_Wyznacz_trase_clicked()
{
    ui->label_blad_x_poczatkowy->setEnabled(0);
    ui->label_blad_x_koncowy->setEnabled(0);
    ui->label_blad_y_poczatkowy->setEnabled(0);
    ui->label_blad_y_koncowy->setEnabled(0);
    if(ui->label_Udalo_sie_zaladowac_mape->isEnabled()){
        ui->label_Udalo_sie_wyznaczyc_trase->setEnabled(0);
        try {
            x_start =stoi(ui->LE_x_poczatkowy->text().toStdString());
        }  catch (...) {
            ui->label_blad_x_poczatkowy->setEnabled(1);
        }
        try {
            x_cel=stoi(ui->LE_x_koncowy->text().toStdString());
        }  catch (...) {
            ui->label_blad_x_koncowy->setEnabled(1);
        }
        try {
            y_start=stoi(ui->LE_y_poczatkowy->text().toStdString());
        }  catch (...) {
            ui->label_blad_y_poczatkowy->setEnabled(1);
        }
        try {
            y_cel=stoi(ui->LE_y_koncowy->text().toStdString());
        }  catch (...) {
            ui->label_blad_y_koncowy->setEnabled(1);
        }
        if(x_start>dane_mapy.MW or x_start<0){
            ui->label_blad_x_poczatkowy->setEnabled(1);
        }
        if(x_cel>dane_mapy.MW or x_cel<0){
            ui->label_blad_x_koncowy->setEnabled(1);
        }
        if(y_start>dane_mapy.MH or y_start<0){
            ui->label_blad_y_poczatkowy->setEnabled(1);
        }
        if(y_cel>dane_mapy.MH or y_cel<0){
            ui->label_blad_y_koncowy->setEnabled(1);
        }

        if((!ui->label_blad_x_poczatkowy->isEnabled()) and (!ui->label_blad_y_poczatkowy->isEnabled()) and (!ui->label_blad_x_koncowy->isEnabled()) and (!ui->label_blad_y_koncowy->isEnabled()))
        {
            start={x_start,y_start};
            cel={x_cel,y_cel};

            i_start = indeksWezla(start, dane_mapy.MW);
            i_cel = indeksWezla(cel, dane_mapy.MW);

            try {
                A_star(mapa, i_start, i_cel, G, P, dane_mapy.MH+dane_mapy.MW+1 , dane_mapy);
                ui->label_Udalo_sie_wyznaczyc_trase->setEnabled(1);
            }  catch (...) {
                ui->label_Udalo_sie_wyznaczyc_trase->setEnabled(0);
            }
            //drukujSciezke(mapa, P, i_start, dane_mapy.MW, dane_mapy.MH);
        }
    }
    else{
        ui->label_Udalo_sie_wyznaczyc_trase->setEnabled(0);

        ui->label_Udalo_sie_wyznaczyc_trase->setEnabled(0);
        try {
            x_start =stoi(ui->LE_x_poczatkowy->text().toStdString());
        }  catch (...) {
            ui->label_blad_x_poczatkowy->setEnabled(1);
        }
        try {
            x_cel=stoi(ui->LE_x_koncowy->text().toStdString());
        }  catch (...) {
            ui->label_blad_x_koncowy->setEnabled(1);
        }
        try {
            y_start=stoi(ui->LE_y_poczatkowy->text().toStdString());
        }  catch (...) {
            ui->label_blad_y_poczatkowy->setEnabled(1);
        }
        try {
            y_cel=stoi(ui->LE_y_koncowy->text().toStdString());
        }  catch (...) {
            ui->label_blad_y_koncowy->setEnabled(1);
        }
    }
}

void MainWindow::on_pB_Zapisz_trase_clicked()
{
    string pobierz_adres =ui->LE_adres_mapy_zapisu->text().toStdString();
    int dlugosc_sciezki=pobierz_adres.length();
    if(dlugosc_sciezki>=4)
    {
        string ostatnie_cztery_znaki;
        ostatnie_cztery_znaki+=pobierz_adres[dlugosc_sciezki-4];
        ostatnie_cztery_znaki+=pobierz_adres[dlugosc_sciezki-3];
        ostatnie_cztery_znaki+=pobierz_adres[dlugosc_sciezki-2];
        ostatnie_cztery_znaki+=pobierz_adres[dlugosc_sciezki-1];
        //cout<<ostatnie_cztery_znaki;
        if(ostatnie_cztery_znaki==".txt")
        {
            ui->label_blad_Sciezka_do_zapisu_pliku->setEnabled(0);

            if(ui->label_Udalo_sie_wyznaczyc_trase->isEnabled()){
                try {
                    zapisSciezke(mapa, P, G, i_start, dane_mapy,pobierz_adres, dane_mapy.MH+dane_mapy.MW+1);

                    ui->label_Rozwiazanie_zapisano_do->setEnabled(1);
                    ui->label_Udalo_sie_zapisac_rozwiazanie->setEnabled(1);
                    ui->label_plik_do_ktorego_zapisano->setEnabled(1);
                    ui->label_plik_do_ktorego_zapisano->setText(ui->LE_adres_mapy_zapisu->text());

                }  catch (...) {
                    ui->label_Rozwiazanie_zapisano_do->setEnabled(0);
                    ui->label_Udalo_sie_zapisac_rozwiazanie->setEnabled(0);
                    ui->label_plik_do_ktorego_zapisano->setEnabled(0);
                    ui->label_plik_do_ktorego_zapisano->setText("-");
                }
            }

        }
        else{
            ui->label_Rozwiazanie_zapisano_do->setEnabled(0);
            ui->label_Udalo_sie_zapisac_rozwiazanie->setEnabled(0);
            ui->label_plik_do_ktorego_zapisano->setEnabled(0);
            ui->label_plik_do_ktorego_zapisano->setText("-");
            ui->label_blad_Sciezka_do_zapisu_pliku->setEnabled(1);
        }
    }
    else{
        ui->label_Rozwiazanie_zapisano_do->setEnabled(0);
        ui->label_Udalo_sie_zapisac_rozwiazanie->setEnabled(0);
        ui->label_plik_do_ktorego_zapisano->setEnabled(0);
        ui->label_plik_do_ktorego_zapisano->setText("-");
        ui->label_blad_Sciezka_do_zapisu_pliku->setEnabled(1);
    }

}
