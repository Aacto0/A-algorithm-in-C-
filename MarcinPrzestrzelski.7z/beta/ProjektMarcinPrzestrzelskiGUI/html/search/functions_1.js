var searchData=
[
  ['drukujg_73',['drukujG',['../_agwiazda_8cpp.html#a57b4c4ae965da5c1365f8a5650f34492',1,'drukujG(char *mapa, double *G, int szerokosc, int wysokosc, int KOSZT_MAKS):&#160;Agwiazda.cpp'],['../_agwiazda_8h.html#a57b4c4ae965da5c1365f8a5650f34492',1,'drukujG(char *mapa, double *G, int szerokosc, int wysokosc, int KOSZT_MAKS):&#160;Agwiazda.cpp']]],
  ['drukujsciezke_74',['drukujSciezke',['../_agwiazda_8cpp.html#ae33ea44c5937ffcadb128f6195759e8b',1,'drukujSciezke(char *mapa, int *P, int i_start, int szerokosc, int wysokosc):&#160;Agwiazda.cpp'],['../_agwiazda_8h.html#ae33ea44c5937ffcadb128f6195759e8b',1,'drukujSciezke(char *mapa, int *P, int i_start, int szerokosc, int wysokosc):&#160;Agwiazda.cpp']]]
];
