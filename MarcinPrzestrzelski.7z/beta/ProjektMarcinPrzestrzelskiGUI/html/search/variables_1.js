var searchData=
[
  ['dane_5fmapy_92',['dane_mapy',['../mainwindow_8cpp.html#a1472bfdb291e6674481e88eb3aa73bbc',1,'mainwindow.cpp']]]
];
