var searchData=
[
  ['heurystyka_11',['heurystyka',['../_agwiazda_8cpp.html#a0c794a27dcf086c31dbe397197aa44d6',1,'heurystyka(int u, int v, daneMapy dane_mapy):&#160;Agwiazda.cpp'],['../_agwiazda_8h.html#a0c794a27dcf086c31dbe397197aa44d6',1,'heurystyka(int u, int v, daneMapy dane_mapy):&#160;Agwiazda.cpp']]]
];
