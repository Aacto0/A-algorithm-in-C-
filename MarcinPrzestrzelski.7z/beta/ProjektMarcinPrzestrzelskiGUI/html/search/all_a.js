var searchData=
[
  ['octile_5fkierunki_33',['octile_kierunki',['../_agwiazda_8cpp.html#a3835d9256c2702de50b1f99a99cf611d',1,'Agwiazda.cpp']]],
  ['octile_5fsasiedzi_34',['octile_sasiedzi',['../_agwiazda_8cpp.html#a66f3ceed8511cb8ecbf4dad59f3dbce4',1,'Agwiazda.cpp']]],
  ['ostatni_35',['ostatni',['../struct_kopiec.html#a4be5c2bd45492818e7aa83ab349b79c9',1,'Kopiec']]]
];
