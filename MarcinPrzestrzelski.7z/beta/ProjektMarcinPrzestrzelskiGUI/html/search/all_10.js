var searchData=
[
  ['v_45',['v',['../struct_krawedz_id.html#a8cda234a7b97308c4bf81d094d71d708',1,'KrawedzId']]]
];
