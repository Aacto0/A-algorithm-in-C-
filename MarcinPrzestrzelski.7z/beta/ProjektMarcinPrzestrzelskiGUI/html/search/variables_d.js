var searchData=
[
  ['w_113',['w',['../struct_krawedz_id.html#a59bc78eb83a517380408c8b8fb945f23',1,'KrawedzId']]],
  ['wartosc_114',['wartosc',['../struct_element_kopca.html#ad948bb797a3dfd11837c60a2c922fee3',1,'ElementKopca']]]
];
