var searchData=
[
  ['i_5fcel_12',['i_cel',['../mainwindow_8cpp.html#ac75d0f41e2325a14de1ebbc033021fd2',1,'mainwindow.cpp']]],
  ['i_5fstart_13',['i_start',['../mainwindow_8cpp.html#aea9b53c36b298e8064344b37eabe93ec',1,'mainwindow.cpp']]],
  ['importmapy_14',['importMapy',['../_agwiazda_8cpp.html#a93e165485e38a95bfded7da5574b841d',1,'importMapy(string sciezka, char *&amp;mapa, daneMapy &amp;danemapy):&#160;Agwiazda.cpp'],['../_agwiazda_8h.html#a93e165485e38a95bfded7da5574b841d',1,'importMapy(string sciezka, char *&amp;mapa, daneMapy &amp;danemapy):&#160;Agwiazda.cpp']]],
  ['indeks_15',['indeks',['../struct_element_kopca.html#a405483188433365037834fa84edfa404',1,'ElementKopca']]],
  ['indekswezla_16',['indeksWezla',['../_agwiazda_8cpp.html#ae81f1c4d2d5c0fda134df28bfd3a3a27',1,'indeksWezla(Wezel2D wezel, int szerokosc):&#160;Agwiazda.cpp'],['../_agwiazda_8h.html#ae81f1c4d2d5c0fda134df28bfd3a3a27',1,'indeksWezla(Wezel2D wezel, int szerokosc):&#160;Agwiazda.cpp']]],
  ['inicjuj_17',['inicjuj',['../_agwiazda_8cpp.html#a0dbabc479d38f1e5f28607db3d54a219',1,'inicjuj(Kopiec &amp;kopiec, int liczba_elementow):&#160;Agwiazda.cpp'],['../_agwiazda_8h.html#a0dbabc479d38f1e5f28607db3d54a219',1,'inicjuj(Kopiec &amp;kopiec, int liczba_elementow):&#160;Agwiazda.cpp']]],
  ['inicjujg_18',['inicjujG',['../_agwiazda_8cpp.html#a6e2f0d329439f159da8e6ba14ca07da0',1,'inicjujG(int MV, int zrodlo, int KOSZT_MAKS):&#160;Agwiazda.cpp'],['../_agwiazda_8h.html#ac71229d7392d2dceef992bcea3e66cbd',1,'inicjujG(int MV, double zrodlo, int KOSZT_MAKS):&#160;Agwiazda.h']]],
  ['inicjujp_19',['inicjujP',['../_agwiazda_8cpp.html#ad0ea0d98b082e88cf97b0834234c4b7f',1,'inicjujP(int MV):&#160;Agwiazda.cpp'],['../_agwiazda_8h.html#ad0ea0d98b082e88cf97b0834234c4b7f',1,'inicjujP(int MV):&#160;Agwiazda.cpp']]]
];
