var indexSectionsWithContent =
{
  0: "acdeghikmnoprstuvwxyz~",
  1: "dekmw",
  2: "u",
  3: "am",
  4: "adghimpwz~",
  5: "cdgimnoprstuvwxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Przestrzenie nazw",
  3: "Pliki",
  4: "Funkcje",
  5: "Zmienne"
};

