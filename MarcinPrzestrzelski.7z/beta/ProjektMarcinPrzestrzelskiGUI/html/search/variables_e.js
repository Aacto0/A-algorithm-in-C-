var searchData=
[
  ['x_115',['x',['../struct_wezel2_d.html#afdd7f9103cd322ca2c89165e48b2cae3',1,'Wezel2D']]],
  ['x_5fcel_116',['x_cel',['../mainwindow_8cpp.html#a9c72932f5028feeaa5f1ac695ff06b93',1,'mainwindow.cpp']]],
  ['x_5fstart_117',['x_start',['../mainwindow_8cpp.html#a18be454ae39e77e0d68b346e7664593a',1,'mainwindow.cpp']]]
];
