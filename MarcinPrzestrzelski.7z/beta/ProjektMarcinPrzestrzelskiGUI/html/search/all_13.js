var searchData=
[
  ['y_54',['y',['../struct_wezel2_d.html#a2f9df7f7e1c47b1387d0a14cc1fe3796',1,'Wezel2D']]],
  ['y_5fcel_55',['y_cel',['../mainwindow_8cpp.html#a14e600a1f65ac1770b6668e4580a5e7f',1,'mainwindow.cpp']]],
  ['y_5fstart_56',['y_start',['../mainwindow_8cpp.html#a6f641fcd70fc611e05fbc32f4bb14451',1,'mainwindow.cpp']]]
];
