var searchData=
[
  ['danemapy_60',['daneMapy',['../structdane_mapy.html',1,'']]]
];
