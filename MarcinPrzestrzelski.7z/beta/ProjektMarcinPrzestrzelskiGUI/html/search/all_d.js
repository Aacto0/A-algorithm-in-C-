var searchData=
[
  ['start_40',['start',['../mainwindow_8cpp.html#affab7179b0954fa3db84f8047da9dead',1,'mainwindow.cpp']]]
];
