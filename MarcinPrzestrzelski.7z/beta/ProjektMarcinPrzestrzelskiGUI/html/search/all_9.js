var searchData=
[
  ['nazwa_5fpliku_32',['nazwa_pliku',['../mainwindow_8cpp.html#a396c90f983bbfbc285b5a1d3dcfafa4e',1,'mainwindow.cpp']]]
];
