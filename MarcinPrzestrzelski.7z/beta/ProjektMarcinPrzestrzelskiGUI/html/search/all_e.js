var searchData=
[
  ['t_41',['t',['../struct_kopiec.html#aa149b3590ddc49b16e833758d91c3f76',1,'Kopiec']]],
  ['typ_42',['typ',['../structdane_mapy.html#a5673e70b80e52fe9c5e8c064c097e0b5',1,'daneMapy']]]
];
