var searchData=
[
  ['wezel2d_86',['wezel2D',['../_agwiazda_8cpp.html#a25464db835a39411f14efeeea550a7bf',1,'wezel2D(int indeks, int szerokosc):&#160;Agwiazda.cpp'],['../_agwiazda_8h.html#a25464db835a39411f14efeeea550a7bf',1,'wezel2D(int indeks, int szerokosc):&#160;Agwiazda.cpp']]],
  ['wstaw_87',['wstaw',['../_agwiazda_8cpp.html#ad73a4b767d3c0d411a9dd3cdce0710d0',1,'wstaw(Kopiec &amp;kopiec, int wartosc, int indeks):&#160;Agwiazda.cpp'],['../_agwiazda_8h.html#ad73a4b767d3c0d411a9dd3cdce0710d0',1,'wstaw(Kopiec &amp;kopiec, int wartosc, int indeks):&#160;Agwiazda.cpp']]]
];
