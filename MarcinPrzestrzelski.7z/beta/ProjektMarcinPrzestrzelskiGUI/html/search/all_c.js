var searchData=
[
  ['rozmiar_39',['rozmiar',['../struct_kopiec.html#a6d178439f3c95da2aeaa450f6ff33f3c',1,'Kopiec']]]
];
