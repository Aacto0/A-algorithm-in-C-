var searchData=
[
  ['g_93',['G',['../mainwindow_8cpp.html#a76bbdf5d1500f11cee3ddd96edc5a175',1,'mainwindow.cpp']]]
];
