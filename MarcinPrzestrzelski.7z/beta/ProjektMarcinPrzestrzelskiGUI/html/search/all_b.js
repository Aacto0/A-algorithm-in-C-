var searchData=
[
  ['p_36',['P',['../mainwindow_8cpp.html#a13940dd61bfef1e80306cc8b428e39e8',1,'mainwindow.cpp']]],
  ['podajpunkt_37',['podajpunkt',['../_agwiazda_8cpp.html#a2647122d4c565289ef4983ec4eb46170',1,'podajpunkt(int &amp;x, int &amp;y):&#160;Agwiazda.cpp'],['../_agwiazda_8h.html#a2647122d4c565289ef4983ec4eb46170',1,'podajpunkt(int &amp;x, int &amp;y):&#160;Agwiazda.cpp']]],
  ['powitanie_38',['powitanie',['../_agwiazda_8cpp.html#a916b05abaa8e2b0e554c4d6a0bb9ee10',1,'powitanie():&#160;Agwiazda.cpp'],['../_agwiazda_8h.html#a916b05abaa8e2b0e554c4d6a0bb9ee10',1,'powitanie():&#160;Agwiazda.cpp']]]
];
