var searchData=
[
  ['cel_91',['cel',['../mainwindow_8cpp.html#ade3bae8a99c051f1ccc84d4e827942a6',1,'mainwindow.cpp']]]
];
