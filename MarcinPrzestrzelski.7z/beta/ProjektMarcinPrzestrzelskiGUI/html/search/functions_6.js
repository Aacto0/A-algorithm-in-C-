var searchData=
[
  ['podajpunkt_84',['podajpunkt',['../_agwiazda_8cpp.html#a2647122d4c565289ef4983ec4eb46170',1,'podajpunkt(int &amp;x, int &amp;y):&#160;Agwiazda.cpp'],['../_agwiazda_8h.html#a2647122d4c565289ef4983ec4eb46170',1,'podajpunkt(int &amp;x, int &amp;y):&#160;Agwiazda.cpp']]],
  ['powitanie_85',['powitanie',['../_agwiazda_8cpp.html#a916b05abaa8e2b0e554c4d6a0bb9ee10',1,'powitanie():&#160;Agwiazda.cpp'],['../_agwiazda_8h.html#a916b05abaa8e2b0e554c4d6a0bb9ee10',1,'powitanie():&#160;Agwiazda.cpp']]]
];
