var searchData=
[
  ['elementkopca_8',['ElementKopca',['../struct_element_kopca.html',1,'']]]
];
