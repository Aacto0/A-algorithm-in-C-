#include "Agwiazda.h"


/// Liczba kierunków/indeksów dla typu mahatan
const int manhatan_kierunki=4;
/// Tablica ze wszystkimi dopuszczalnymi kierunkami dla typu manhatan
Wezel2D manhatan_sasiedzi[manhatan_kierunki] = {{-1,0}, {0,-1}, {1,0}, {0,1}};
/// Liczba kierunków/indeksów dla typu octile
const int octile_kierunki = 8;
/// Tablica ze wszystkimi dopuszczalnymi kierunkami dla typu octile
Wezel2D octile_sasiedzi[octile_kierunki] = {{-1,0}, {0,-1}, {1,0}, {0,1}, {-1,-1}, {1,-1}, {1,-1}, {1,1}};

void powitanie(){
    cout<<"ALOGRYTM A* DO MAP 2D ALFA"<<endl<<"Marcin Przestrzelski gr.11"<<endl;
    cout<<"Witaj"<<endl<<"Jest to progarm realizujacy alogrytm A*, czyli znajdujacy najkrutsza droge miedzy 2 punktami, na wskazanej mapie"<<endl<<"Aby badac mape, musi ona znajdowac sie w katalogu map."<<endl<<endl;
}

void podajpunkt(int &x, int &y){
    int wspolzedna;
    while(!(cin>>wspolzedna)){
        cout<<"Podano bledna wartosc."<<endl;
        cout<<"Podaj wartosc jeszcze raz."<<endl;
        cin.clear();
        cin.sync();
    }
    x=wspolzedna;
    //cin>>wspolzedna;
    while(!(cin>>wspolzedna)){
        cout<<"Podano bledna wartosc."<<endl;
        cout<<"Podaj wartosc jeszcze raz."<<endl;
        cin.clear();
        cin.sync();
    }
    y=wspolzedna;
    cout<<"Podany punkt to ("<<x<<","<<y<<")."<<endl;
}

bool importMapy(string sciezka, char *&mapa, daneMapy &danemapy)
{
    fstream plik;
    string linia;
    int licznik=0;
    plik.open(sciezka);
    if(!plik.good())
    {
        plik.close();
        return 0;
    }
    else
    {
        getline (plik,linia);
        linia.erase(0,5);
        cout<<"Typ wczytanej mapy to "<<linia<<endl;
        danemapy.typ=linia;
        getline (plik,linia);
        linia.erase(0,7);
        cout<<"Wysokosc wczytanej mapy to "<<linia<<endl;
        danemapy.MH=atoi(linia.c_str());
        getline (plik,linia);
        linia.erase(0,6);
        cout<<"Szerokosc wczytanej mapy to "<<linia<<endl;
        danemapy.MW=atoi(linia.c_str());
        getline (plik,linia);

        mapa=new char[danemapy.MH * danemapy.MW];

        while(getline (plik,linia))
        {
            for(int i=0;i<danemapy.MW;i++)
            {
                mapa[licznik*danemapy.MW+i]=linia[i];
                //cout<<mapa[licznik*danemapy.MW+i];
            }
            licznik++;
            //cout<<endl;
        }
    }
    plik.close();
    return 1;
}

void inicjuj(Kopiec &kopiec, int liczba_elementow)
{
    kopiec.rozmiar = liczba_elementow + 1;
    kopiec.t = new ElementKopca[kopiec.rozmiar];
    kopiec.ostatni = 0;
}

void wstaw(Kopiec &kopiec, int wartosc, int indeks)
{
    if(kopiec.ostatni + 1 == kopiec.rozmiar)
        return;
    ElementKopca element;
    element.wartosc = wartosc;
    element.indeks = indeks;
    kopiec.ostatni++;
    kopiec.t[kopiec.ostatni] = element;
    int indeks_nowego = kopiec.ostatni;
    int indeks_rodzica = indeks_nowego / 2;
    while(indeks_rodzica > 0)
    {
        if(kopiec.t[indeks_nowego].wartosc < kopiec.t[indeks_rodzica].wartosc)
        {
            ElementKopca p = kopiec.t[indeks_nowego];
            kopiec.t[indeks_nowego] = kopiec.t[indeks_rodzica];
            kopiec.t[indeks_rodzica] = p;
            indeks_nowego = indeks_rodzica;
            indeks_rodzica = indeks_nowego / 2;
        }
        else
        {
            break;
        }
    }
}

ElementKopca zdejmijNajmniejszyElement(Kopiec &kopiec)
{
    if(kopiec.ostatni == 0)
        return ElementKopca();
    ElementKopca najmniejszy = kopiec.t[1];
    int do_pobrania = 1;
    while(do_pobrania < kopiec.ostatni)
    {
        int potomek_1 = 2*do_pobrania;
        int potomek_2 = 2*do_pobrania + 1;
        int najmniejszy_potomek = potomek_1;
        if(potomek_1 > kopiec.ostatni)
            break;
        else if(potomek_2 > kopiec.ostatni )
            najmniejszy_potomek = potomek_1;
        else if(kopiec.t[potomek_2].wartosc < kopiec.t[potomek_1].wartosc)
            najmniejszy_potomek = potomek_2;
        kopiec.t[do_pobrania] = kopiec.t[najmniejszy_potomek];
        do_pobrania = najmniejszy_potomek;
    }
    kopiec.t[do_pobrania] = kopiec.t[kopiec.ostatni];
    kopiec.ostatni--;
    return najmniejszy;
}

int indeksWezla(Wezel2D wezel, int szerokosc)
{
    return wezel.x*szerokosc + wezel.y;
}
Wezel2D wezel2D(int indeks, int szerokosc)
{
    Wezel2D wezel = {indeks/szerokosc, indeks%szerokosc};
    return wezel;
}

KrawedzId generujKrawedz(int u, int kierunek, daneMapy dane_mapy, int KOSZT_MAKS, char *mapa)
{
    Wezel2D wezel = wezel2D(u, dane_mapy.MW);
    Wezel2D sasiad;
    if(dane_mapy.typ=="octile"){
        sasiad.x = wezel.x + octile_sasiedzi[kierunek].x;
        sasiad.y = wezel.y + octile_sasiedzi[kierunek].y;
    }
    if(dane_mapy.typ=="manhatan"){
        sasiad.x = wezel.x + manhatan_sasiedzi[kierunek].x;
        sasiad.y = wezel.y + manhatan_sasiedzi[kierunek].y;
    }
    KrawedzId krawedz;
    krawedz.u = u;
    krawedz.v = indeksWezla(sasiad, dane_mapy.MW);// indeks s¡siada
    if(sasiad.x<0 || sasiad.y<0 || sasiad.x>=dane_mapy.MH || sasiad.y>=dane_mapy.MW)
        krawedz.w = KOSZT_MAKS; // Omijamy w¦zªy poza map¡
    else if(mapa[u]=='@' || mapa[krawedz.v]=='@')
        krawedz.w = KOSZT_MAKS; // Omijamy w¦zªy z przeszkod¡
    else if(kierunek>3)
        krawedz.w = sqrt(2);
    else
        krawedz.w = 1;

    return krawedz;
}

double *inicjujG(int MV, int zrodlo, int KOSZT_MAKS)
{
    double *G = new double[MV];
    for(int i=0; i<MV; i++)
        G[i] = double(KOSZT_MAKS);
    G[zrodlo] = 0.0;
    return G;
}
void drukujG(char *mapa, double *G, int szerokosc, int wysokosc, int KOSZT_MAKS)
{
    cout << "Tablica G: " << endl;
    int w = 3;
    int liczba_odwiedzonych = 0;
    for(int i=0; i<wysokosc; i++)
    {
        for(int j=0; j<szerokosc; j++)
        {
            Wezel2D wezel = {i,j};
            int id = indeksWezla(wezel, szerokosc);
            if(mapa[id]=='@')
                cout << setw(w) << '@';
            else
                cout << setw(w) << G[id];
            if(G[id] < KOSZT_MAKS)
                liczba_odwiedzonych++;
        }
        cout << endl;
    }
    cout << endl << "Liczba odwiedzonych wezlów: " << liczba_odwiedzonych <<endl;
}
void drukujSciezke(char *mapa, int *P, int i_start, int szerokosc, int wysokosc)
{
    cout << "Sciezka (znak *): " << endl;
    int w = 3;
    char *t = new char[szerokosc * wysokosc];
    for(int i=0; i < szerokosc * wysokosc; i++)
    t[i] = mapa[i];
    while(i_start != -1)
    {
        t[i_start] = '*';
        i_start = P[i_start];
    }
    for(int i=0; i<wysokosc; i++)
    {
        for(int j=0; j<szerokosc; j++)
        {
            Wezel2D wezel = {i,j};
            int id = indeksWezla(wezel, szerokosc);
            cout << setw(w) << t[id];
        }
        cout << endl;
    }
    cout << endl;
    delete []t;
}
int *inicjujP(int MV)
{
    int *P = new int[MV];
    for(int i=0; i<MV; i++)
        P[i] = -1;
    return P;
}
void zapisSciezke(char *mapa, int *P, double *G, int i_start, daneMapy dane_mapy, string sciezka, int KOSZT_MAKS)
{
    ofstream plik;
    plik.open(sciezka);
    if(plik.good())
    {
        cout<<"Udalo sie zapisac rozwiazanie"<<endl;
        if(G[i_start]==KOSZT_MAKS)
        {
            plik <<"Brak mozliwosci poloczenie miedzy punktami"<<endl;
        }
        else
        {
            plik << "Minimalny koszt dotarcia : "<<G[i_start]<<endl<<endl;
            plik << "Sciezka (znak *): " << endl;
            //int w = 3;
            char *t = new char[dane_mapy.MW * dane_mapy.MH];
            for(int i=0; i < dane_mapy.MW * dane_mapy.MH; i++)
            t[i] = mapa[i];
            while(i_start != -1)
            {
                t[i_start] = '*';
                i_start = P[i_start];
            }
            for(int i=0; i<dane_mapy.MH; i++)
            {
                for(int j=0; j<dane_mapy.MW; j++)
                {
                    Wezel2D wezel = {i,j};
                    int id = indeksWezla(wezel, dane_mapy.MW);
                    plik << t[id];
                }
                plik << endl;
            }
            plik << endl;
            delete []t;
        }

        cout<<"Zapisano do pliku "<<sciezka<<endl;
    }
    else
    {
        cout<<"Nie udalo sie zapisac rozwiazania"<<endl;
    }
    plik.close();
}
int heurystyka(int u, int v, daneMapy dane_mapy)
{
    Wezel2D wu = wezel2D(u, dane_mapy.MW);
    Wezel2D wv = wezel2D(v, dane_mapy.MW);
    return sqrt(pow(wu.x - wv.x, 2) + pow(wu.y - wv.y, 2));
}
void A_star(char *mapa, int i_start, int i_cel, double *&G, int *&P, int KOSZT_MAKS, daneMapy dane_mapy)
{
    // Przeszukiwanie wstecz (od celu do startu)
    G = inicjujG(dane_mapy.MH*dane_mapy.MW, i_cel, KOSZT_MAKS);
    P = inicjujP(dane_mapy.MH*dane_mapy.MW);
    Kopiec Q;
    inicjuj(Q, dane_mapy.MH*dane_mapy.MW);
    wstaw(Q, G[i_cel] + heurystyka(i_start, i_cel, dane_mapy), i_cel); //inaczej ni» w Dijkstra
    while(Q.ostatni != 0)
    {
        ElementKopca najmniejszy_element = zdejmijNajmniejszyElement(Q);
        int u = najmniejszy_element.indeks;
        if(u == i_start)
            break;
        int K;
        if(dane_mapy.typ=="octile")
        {
            K=octile_kierunki;
        }
        else if(dane_mapy.typ=="manhatan")
        {
            K=manhatan_kierunki;
        }
        else{
            exit(0);
        }
        for(int k=0; k<K; k++)
        {
            KrawedzId krawedz = generujKrawedz(u,k, dane_mapy, KOSZT_MAKS, mapa);
            if(krawedz.w < KOSZT_MAKS)
            {
                if(G[krawedz.v] > G[u] + krawedz.w)
                {
                    G[krawedz.v] = G[u] + krawedz.w;
                    P[krawedz.v] = u;
                    wstaw(Q, G[krawedz.v] + heurystyka(i_start, krawedz.v, dane_mapy),krawedz.v); //inaczej ni» w Dijkstra
                }
            }
        }
    }
}
