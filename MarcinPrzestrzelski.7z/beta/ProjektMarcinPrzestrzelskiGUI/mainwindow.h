#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "Agwiazda.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    /** \brief
     *
     * Funkcja sprawdza czy można wczytać mapę przy pomocy podanych danych i prubuje to zrobić. Funkcja informuje też użytkownika o ewentualnych błędach we wskazanych polach.
     */
    void on_pB_Zaladuj_mape_clicked();

    /** \brief
     *
     * Funkcja sprawdza czy można wyznaczyć najkrótszą trasę przy pomocy podanych danych i prubuje to zrobić. Funkcja informuje też użytkownika o ewentualnych błędach we wskazanych polach.
     */
    void on_pB_Wyznacz_trase_clicked();

    /** \brief
     *
     * Funkcja sprawdza czy można zapisać mapę przy pomocy podanych danych i prubuje to zrobić. Funkcja informuje też użytkownika o ewentualnych błędach we wskazanych polach.
     */
    void on_pB_Zapisz_trase_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
