
#ifndef AGWIAZDA_H
#define AGWIAZDA_H
# include <iostream>
# include <cstdlib>
# include <iomanip>
# include <cmath>
# include <fstream>
# include <string>
# include <sstream>

using namespace std;

/** \brief Dane Mapy
 *
 * Zawiera szerokość, wysokość i typ mapy
 */
struct daneMapy{
    /// Szerokość mapy
    int MW;
    /// Wysokość mapy
    int MH;
    /// Typ mapy(dopuszczalne typy to octile i manhatan)
    string typ;
};

/** \brief Wezel w formacie 2D
 *
 * Zawiera współżędne węzła w formacie 2D
 */
struct Wezel2D{
    /// Współżędne x i y węzła
    int x, y;
};

/** \brief Element Kopca
 *
 * Zawiera współżędne węzła w formacie 2D
 */
struct ElementKopca{
    /// Indeks krawędzi lub węzła
    int indeks;
    /// Waga krawędzi lub długość(koszt) ścieżki
    int wartosc;
};

/** \brief Kopiec
 *
 * Struktura danych - kopiec
 */
struct Kopiec{
    /// tablica dynamiczna jednowymiarowa
    ElementKopca *t;
    /// indeks ostatniego elementu
    int ostatni;
    /// rozmiar tablicy jednowymiarowej
    int rozmiar;
};

/** \brief Krawędź
 *
 * Opisuje ścieżkę między dwoma punktami
 */
struct KrawedzId
{
    /// indeks węzła początkowego
    int u;
    /// indeks węzła końcowego
    int v;
    /// waga
    double w;
};

/** \brief Powitanie
 *
 * Funkcja stworzona w wersji tekstowej(alfa), służyła do wyświetlania panelu z powitaniem dla użytkowjika.
 */
void powitanie();

/** \brief Pobieranie współżędnych punktu
 *
 * Funkcja stworzona w wersji tekstowej(alfa), służyła do pobrania od użytkownika współżędnych punktu.
 * \param x Współżędna x
 * \param y Współżędna y
 */
void podajpunkt(int &x, int &y);

/** \brief Wczytanie mapy
 *
 * Funkcaj pobiera mapę z pliku tekstowego. Zwraca wartość true jeżeli udało się pobrać i false jeżeli się nie udało.
 * \param sciezka Ścieżka do pliku z mapą
 * \param mapa Tablica przechowująca mapę
 * \param daneMapy Struktura przechowująca dane mapy
 * \return Informacja czy udało się otworzyć mapę
 */
bool importMapy(string sciezka, char *&mapa, daneMapy &danemapy);

/** \brief Zainicjowanie kopca
 *
 * Funckja dodaje nowy element do kpca.
 * \param kopiec Kopiec
 * \param liczba_elementow Liczba elementów kopca
 */
void inicjuj(Kopiec &kopiec, int liczba_elementow);

/** \brief Wstawienie elementu dla kopca
 *
 * Funcja wpisuje element do kopca.
 * \param kopiec Kopiec
 * \param wartosc Wartość elementu
 * \param indeks Indeks elementu
 */
void wstaw(Kopiec &kopiec, int wartosc, int indeks);

/** \brief Zdejęcie najmniejszęgo elementu kopca
 *
 * Funckja zwraca najmniejszy element kopca.
 * \param kopiec Kopiec
 * \return Najmniejszy element kopca
 */
ElementKopca zdejmijNajmniejszyElement(Kopiec &kopiec);

/** \brief Wartość indeksu węzła
 *
 * Funkcaj zwraca indeks węzłu.
 * \param wezel Węzeł
 * \param szerokoszc Szerokość mapy
 * \return Indeks węzłu
 */
int indeksWezla(Wezel2D wezel, int szerokosc);
/** Zamiana węzła w 2D na indeks
 *
 * Funkcj zamienia węzeł 2D na indeks(wezel.x*szerokosc + wezel.y)
 * \param indeks
 * \param szerokosc Szerokość mapy
 * \return Indeks węzła
 */
Wezel2D wezel2D(int indeks, int szerokosc);
/** Generuj najkrótszą krawędź
 *
 * Funkcja tworzy najkrutszą dostępną krawędź dla danej mapy o danym typie z podanego węzła
 * \param u Indeks węzła
 * \param kierunek Indek kierunku pobieranego z tablicy kierunków
 * \param dane_Mapy Struktura przechowująca dane mapy
 * \param KOSZT_MAKS Wartosc informująca algorytm, że na dany punkt nie możne "wejść". Wartość ta jest wyliczana na podstawie długości i szerokości mapy.
 * \param mapa Tablica z mapą
 * \return Najkrutsza dostępna krawędź
 */
KrawedzId generujKrawedz(int u, int kierunek, daneMapy dane_mapy, int KOSZT_MAKS, char *mapa);

/** Inicjuj tablicę kierunków
 *
 * Funkcja inicjuje i wypełnia tablicę kierunków ruchu wartościami -1.
 * \param MV Wysokość mapy * szerokość mapy
 * \return Zwraca tablicę ze wszystkimi węzłami ustawionymi na -1
 */
int *inicjujP(int MV);
/** \brief Inicjuj tablicę kosztu dotarcia
 *
 * Funkcja inicjuje i wypełnia tablicę kosztu dotarcia kosztem maksymalnym.
 * \param MV Wysokość mapy * szerokość mapy
 * \param zrodlo indeks punktu początkowego
 * \param KOSZT_MAKS Wartosc informująca algorytm, że na dany punkt nie możne "wejść". Wartość ta jest wyliczana na podstawie długości i szerokości mapy.
 * \return Zwraca tablicę ze wszystkimi węzłami ustawionymi na KOSZT_MAKS
 */
int *inicjujG(int MV, double zrodlo, int KOSZT_MAKS);

/** \brief Wypisz tablicę kosztu dotarcia
 *
 * Funkcja stworzona w wersji tekstowej(alfa), służyła do wypisania tablicy kosztu dotarcia
 * \param mapa Tablica z mapą
 * \param G Tabica kosztu dotarcia
 * \param szerokosc Szerokość mapy
 * \param wysokosc Wysokość mapy
 * \param KOSZT_MAKS Wartosc informująca algorytm, że na dany punkt nie możne "wejść". Wartość ta jest wyliczana na podstawie długości i szerokości mapy.
 */
void drukujG(char *mapa, double *G, int szerokosc, int wysokosc, int KOSZT_MAKS);
/** \brief Drukowanie ścieżki
 *
 * Funkcja stworzona w wersji tekstowe(alfa), służyła do testowania i wydrukowania ścieżki.
 * \param map Tablica z mapą
 * \param P Tablica ze ścieżką
 * \param i_start Indeks punktu początkowego
 * \param szerokosc Szerokość mapy
 * \param wysokosc Wysokość mapy
 */
void drukujSciezke(char *mapa, int *P, int i_start, int szerokosc, int wysokosc);
/** \brief Zapisanie ścieżki
 *
 * Funkcja zapisuje plik z rozwiązaniem omawianego problemu.
 * \param mapa Tablica z mapą
 * \param P Tablica ze ścieżką
 * \param G Tabica kosztu dotarcia
 * \param i_start Indeks punktu początkowego
 */
void zapisSciezke(char *mapa, int *P, double *G, int i_start, daneMapy dane_mapy, string sciezka, int KOSZT_MAKS);

/** \brief Heurystyka
 *
 * Funkcja wylicza teoretyczną(kartezjańską) najkrótszą ścieżkę między dwoma punktami.
 * \param u Indeks punktu pierwszego
 * \param v Indeks punktu drugiego
 * \param dane_mapy Struktura przechowująca dane mapy
 * \return Kartezjańska najkrótsza ścieżka między dwoma punktami sqrt((x1-x2)^2+(y1-y2)^2)
 */
int heurystyka(int u, int v, daneMapy dane_mapy);

/** \brief Algorytm A gwiazda
 *
 * Główna funkcja w programie, wywołująca algorytm A gwiazda na wskazanej mapie.
 * \param mapa Mapa w której chcemy znaleźć najkrótszą ścieżkę
 * \param i_start Indeks punktu początkowego
 * \param i_cel Indeks punktu końcowego
 * \param G Tabica kosztu dotarcia
 * \param P Tablica ze ścieżką
 * \param KOSZT_MAKS Wartosc informująca algorytm, że na dany punkt nie możne "wejść". Wartość ta jest wyliczana na podstawie długości i szerokości mapy.
 * \param dane_mapy Struktura przechowująca dane mapy
 */
void A_star(char *mapa, int i_start, int i_cel, double *&G, int *&P, int KOSZT_MAKS, daneMapy dane_mapy);

#endif // AGWIAZDA_H
