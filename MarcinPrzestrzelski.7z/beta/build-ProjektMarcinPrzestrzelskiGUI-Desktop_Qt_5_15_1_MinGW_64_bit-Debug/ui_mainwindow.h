/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *widget;
    QVBoxLayout *verticalLayout_11;
    QVBoxLayout *verticalLayout_9;
    QHBoxLayout *horizontalLayout_9;
    QVBoxLayout *verticalLayout;
    QLabel *label_Sciezka_do_pliku_z_mapa;
    QHBoxLayout *horizontalLayout;
    QLineEdit *LE_adres_mapy_odczytu;
    QLabel *label_blad_Sciezka_do_pliku_z_mapa;
    QVBoxLayout *verticalLayout_8;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_Wspolzedne_punktu_poczatkowego;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_x_poczatkowy;
    QLineEdit *LE_x_poczatkowy;
    QLabel *label_blad_x_poczatkowy;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_y_poczatkowy;
    QLineEdit *LE_y_poczatkowy;
    QLabel *label_blad_y_poczatkowy;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_wspolzedne_punktu_koncowego;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_x_koncowy;
    QLineEdit *LE_x_koncowy;
    QLabel *label_blad_x_koncowy;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_y_koncowy;
    QLineEdit *LE_y_koncowy;
    QLabel *label_blad_y_koncowy;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_Sciezka_do_zapisu_pliku;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *LE_adres_mapy_zapisu;
    QLabel *label_blad_Sciezka_do_zapisu_pliku;
    QHBoxLayout *horizontalLayout_10;
    QVBoxLayout *verticalLayout_5;
    QPushButton *pB_Zaladuj_mape;
    QLabel *label_Udalo_sie_zaladowac_mape;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_Zaladowano_mape_z;
    QLabel *label_pilik_z_ktorego_pobrano;
    QVBoxLayout *verticalLayout_6;
    QPushButton *pB_Wyznacz_trase;
    QLabel *label_Udalo_sie_wyznaczyc_trase;
    QVBoxLayout *verticalLayout_7;
    QPushButton *pB_Zapisz_trase;
    QLabel *label_Udalo_sie_zapisac_rozwiazanie;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_Rozwiazanie_zapisano_do;
    QLabel *label_plik_do_ktorego_zapisano;
    QVBoxLayout *verticalLayout_10;
    QLabel *label_Uwaga;
    QLabel *label_tresc_uwagi;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(951, 651);
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        QBrush brush1(QColor(255, 170, 127, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        MainWindow->setPalette(palette);
        MainWindow->setCursor(QCursor(Qt::ArrowCursor));
        MainWindow->setAnimated(true);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 20, 871, 561));
        verticalLayout_11 = new QVBoxLayout(widget);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        verticalLayout_11->setContentsMargins(0, 0, 0, 0);
        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setSpacing(15);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        verticalLayout->setContentsMargins(-1, -1, 0, 100);
        label_Sciezka_do_pliku_z_mapa = new QLabel(widget);
        label_Sciezka_do_pliku_z_mapa->setObjectName(QString::fromUtf8("label_Sciezka_do_pliku_z_mapa"));
        QFont font;
        font.setPointSize(9);
        label_Sciezka_do_pliku_z_mapa->setFont(font);

        verticalLayout->addWidget(label_Sciezka_do_pliku_z_mapa);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        LE_adres_mapy_odczytu = new QLineEdit(widget);
        LE_adres_mapy_odczytu->setObjectName(QString::fromUtf8("LE_adres_mapy_odczytu"));

        horizontalLayout->addWidget(LE_adres_mapy_odczytu);

        label_blad_Sciezka_do_pliku_z_mapa = new QLabel(widget);
        label_blad_Sciezka_do_pliku_z_mapa->setObjectName(QString::fromUtf8("label_blad_Sciezka_do_pliku_z_mapa"));
        label_blad_Sciezka_do_pliku_z_mapa->setEnabled(true);
        QFont font1;
        font1.setPointSize(8);
        label_blad_Sciezka_do_pliku_z_mapa->setFont(font1);
        label_blad_Sciezka_do_pliku_z_mapa->setCursor(QCursor(Qt::ArrowCursor));

        horizontalLayout->addWidget(label_blad_Sciezka_do_pliku_z_mapa);


        verticalLayout->addLayout(horizontalLayout);


        horizontalLayout_9->addLayout(verticalLayout);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_Wspolzedne_punktu_poczatkowego = new QLabel(widget);
        label_Wspolzedne_punktu_poczatkowego->setObjectName(QString::fromUtf8("label_Wspolzedne_punktu_poczatkowego"));
        label_Wspolzedne_punktu_poczatkowego->setFont(font);

        verticalLayout_3->addWidget(label_Wspolzedne_punktu_poczatkowego);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_x_poczatkowy = new QLabel(widget);
        label_x_poczatkowy->setObjectName(QString::fromUtf8("label_x_poczatkowy"));

        horizontalLayout_3->addWidget(label_x_poczatkowy);

        LE_x_poczatkowy = new QLineEdit(widget);
        LE_x_poczatkowy->setObjectName(QString::fromUtf8("LE_x_poczatkowy"));

        horizontalLayout_3->addWidget(LE_x_poczatkowy);

        label_blad_x_poczatkowy = new QLabel(widget);
        label_blad_x_poczatkowy->setObjectName(QString::fromUtf8("label_blad_x_poczatkowy"));
        label_blad_x_poczatkowy->setEnabled(true);
        label_blad_x_poczatkowy->setCursor(QCursor(Qt::ArrowCursor));

        horizontalLayout_3->addWidget(label_blad_x_poczatkowy);


        verticalLayout_3->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_y_poczatkowy = new QLabel(widget);
        label_y_poczatkowy->setObjectName(QString::fromUtf8("label_y_poczatkowy"));

        horizontalLayout_4->addWidget(label_y_poczatkowy);

        LE_y_poczatkowy = new QLineEdit(widget);
        LE_y_poczatkowy->setObjectName(QString::fromUtf8("LE_y_poczatkowy"));

        horizontalLayout_4->addWidget(LE_y_poczatkowy);

        label_blad_y_poczatkowy = new QLabel(widget);
        label_blad_y_poczatkowy->setObjectName(QString::fromUtf8("label_blad_y_poczatkowy"));
        label_blad_y_poczatkowy->setEnabled(true);
        label_blad_y_poczatkowy->setCursor(QCursor(Qt::ArrowCursor));

        horizontalLayout_4->addWidget(label_blad_y_poczatkowy);


        verticalLayout_3->addLayout(horizontalLayout_4);


        verticalLayout_8->addLayout(verticalLayout_3);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        label_wspolzedne_punktu_koncowego = new QLabel(widget);
        label_wspolzedne_punktu_koncowego->setObjectName(QString::fromUtf8("label_wspolzedne_punktu_koncowego"));
        label_wspolzedne_punktu_koncowego->setFont(font1);

        verticalLayout_4->addWidget(label_wspolzedne_punktu_koncowego);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_x_koncowy = new QLabel(widget);
        label_x_koncowy->setObjectName(QString::fromUtf8("label_x_koncowy"));

        horizontalLayout_5->addWidget(label_x_koncowy);

        LE_x_koncowy = new QLineEdit(widget);
        LE_x_koncowy->setObjectName(QString::fromUtf8("LE_x_koncowy"));

        horizontalLayout_5->addWidget(LE_x_koncowy);

        label_blad_x_koncowy = new QLabel(widget);
        label_blad_x_koncowy->setObjectName(QString::fromUtf8("label_blad_x_koncowy"));
        label_blad_x_koncowy->setEnabled(true);
        label_blad_x_koncowy->setCursor(QCursor(Qt::ArrowCursor));

        horizontalLayout_5->addWidget(label_blad_x_koncowy);


        verticalLayout_4->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        label_y_koncowy = new QLabel(widget);
        label_y_koncowy->setObjectName(QString::fromUtf8("label_y_koncowy"));

        horizontalLayout_6->addWidget(label_y_koncowy);

        LE_y_koncowy = new QLineEdit(widget);
        LE_y_koncowy->setObjectName(QString::fromUtf8("LE_y_koncowy"));

        horizontalLayout_6->addWidget(LE_y_koncowy);

        label_blad_y_koncowy = new QLabel(widget);
        label_blad_y_koncowy->setObjectName(QString::fromUtf8("label_blad_y_koncowy"));
        label_blad_y_koncowy->setEnabled(true);
        label_blad_y_koncowy->setCursor(QCursor(Qt::ArrowCursor));

        horizontalLayout_6->addWidget(label_blad_y_koncowy);


        verticalLayout_4->addLayout(horizontalLayout_6);


        verticalLayout_8->addLayout(verticalLayout_4);


        horizontalLayout_9->addLayout(verticalLayout_8);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(-1, -1, -1, 100);
        label_Sciezka_do_zapisu_pliku = new QLabel(widget);
        label_Sciezka_do_zapisu_pliku->setObjectName(QString::fromUtf8("label_Sciezka_do_zapisu_pliku"));
        label_Sciezka_do_zapisu_pliku->setFont(font);

        verticalLayout_2->addWidget(label_Sciezka_do_zapisu_pliku);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        LE_adres_mapy_zapisu = new QLineEdit(widget);
        LE_adres_mapy_zapisu->setObjectName(QString::fromUtf8("LE_adres_mapy_zapisu"));

        horizontalLayout_2->addWidget(LE_adres_mapy_zapisu);

        label_blad_Sciezka_do_zapisu_pliku = new QLabel(widget);
        label_blad_Sciezka_do_zapisu_pliku->setObjectName(QString::fromUtf8("label_blad_Sciezka_do_zapisu_pliku"));
        label_blad_Sciezka_do_zapisu_pliku->setEnabled(true);
        label_blad_Sciezka_do_zapisu_pliku->setCursor(QCursor(Qt::ArrowCursor));

        horizontalLayout_2->addWidget(label_blad_Sciezka_do_zapisu_pliku);


        verticalLayout_2->addLayout(horizontalLayout_2);


        horizontalLayout_9->addLayout(verticalLayout_2);


        verticalLayout_9->addLayout(horizontalLayout_9);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        pB_Zaladuj_mape = new QPushButton(widget);
        pB_Zaladuj_mape->setObjectName(QString::fromUtf8("pB_Zaladuj_mape"));
        pB_Zaladuj_mape->setFont(font);

        verticalLayout_5->addWidget(pB_Zaladuj_mape);

        label_Udalo_sie_zaladowac_mape = new QLabel(widget);
        label_Udalo_sie_zaladowac_mape->setObjectName(QString::fromUtf8("label_Udalo_sie_zaladowac_mape"));
        label_Udalo_sie_zaladowac_mape->setEnabled(false);
        label_Udalo_sie_zaladowac_mape->setAutoFillBackground(false);
        label_Udalo_sie_zaladowac_mape->setWordWrap(false);

        verticalLayout_5->addWidget(label_Udalo_sie_zaladowac_mape);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(15);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        label_Zaladowano_mape_z = new QLabel(widget);
        label_Zaladowano_mape_z->setObjectName(QString::fromUtf8("label_Zaladowano_mape_z"));
        label_Zaladowano_mape_z->setEnabled(false);

        horizontalLayout_7->addWidget(label_Zaladowano_mape_z);

        label_pilik_z_ktorego_pobrano = new QLabel(widget);
        label_pilik_z_ktorego_pobrano->setObjectName(QString::fromUtf8("label_pilik_z_ktorego_pobrano"));
        label_pilik_z_ktorego_pobrano->setEnabled(false);

        horizontalLayout_7->addWidget(label_pilik_z_ktorego_pobrano);


        verticalLayout_5->addLayout(horizontalLayout_7);


        horizontalLayout_10->addLayout(verticalLayout_5);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(-1, -1, -1, 40);
        pB_Wyznacz_trase = new QPushButton(widget);
        pB_Wyznacz_trase->setObjectName(QString::fromUtf8("pB_Wyznacz_trase"));
        pB_Wyznacz_trase->setFont(font);

        verticalLayout_6->addWidget(pB_Wyznacz_trase);

        label_Udalo_sie_wyznaczyc_trase = new QLabel(widget);
        label_Udalo_sie_wyznaczyc_trase->setObjectName(QString::fromUtf8("label_Udalo_sie_wyznaczyc_trase"));
        label_Udalo_sie_wyznaczyc_trase->setEnabled(false);

        verticalLayout_6->addWidget(label_Udalo_sie_wyznaczyc_trase);


        horizontalLayout_10->addLayout(verticalLayout_6);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setSizeConstraint(QLayout::SetDefaultConstraint);
        pB_Zapisz_trase = new QPushButton(widget);
        pB_Zapisz_trase->setObjectName(QString::fromUtf8("pB_Zapisz_trase"));
        pB_Zapisz_trase->setFont(font);

        verticalLayout_7->addWidget(pB_Zapisz_trase);

        label_Udalo_sie_zapisac_rozwiazanie = new QLabel(widget);
        label_Udalo_sie_zapisac_rozwiazanie->setObjectName(QString::fromUtf8("label_Udalo_sie_zapisac_rozwiazanie"));
        label_Udalo_sie_zapisac_rozwiazanie->setEnabled(false);

        verticalLayout_7->addWidget(label_Udalo_sie_zapisac_rozwiazanie);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(15);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        label_Rozwiazanie_zapisano_do = new QLabel(widget);
        label_Rozwiazanie_zapisano_do->setObjectName(QString::fromUtf8("label_Rozwiazanie_zapisano_do"));
        label_Rozwiazanie_zapisano_do->setEnabled(false);

        horizontalLayout_8->addWidget(label_Rozwiazanie_zapisano_do);

        label_plik_do_ktorego_zapisano = new QLabel(widget);
        label_plik_do_ktorego_zapisano->setObjectName(QString::fromUtf8("label_plik_do_ktorego_zapisano"));
        label_plik_do_ktorego_zapisano->setEnabled(false);

        horizontalLayout_8->addWidget(label_plik_do_ktorego_zapisano);


        verticalLayout_7->addLayout(horizontalLayout_8);


        horizontalLayout_10->addLayout(verticalLayout_7);


        verticalLayout_9->addLayout(horizontalLayout_10);


        verticalLayout_11->addLayout(verticalLayout_9);

        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        label_Uwaga = new QLabel(widget);
        label_Uwaga->setObjectName(QString::fromUtf8("label_Uwaga"));
        QFont font2;
        font2.setPointSize(10);
        label_Uwaga->setFont(font2);
        label_Uwaga->setAlignment(Qt::AlignBottom|Qt::AlignLeading|Qt::AlignLeft);

        verticalLayout_10->addWidget(label_Uwaga);

        label_tresc_uwagi = new QLabel(widget);
        label_tresc_uwagi->setObjectName(QString::fromUtf8("label_tresc_uwagi"));
        label_tresc_uwagi->setEnabled(true);
        QFont font3;
        font3.setPointSize(8);
        font3.setBold(false);
        font3.setWeight(50);
        font3.setStrikeOut(false);
        font3.setKerning(true);
        label_tresc_uwagi->setFont(font3);
        label_tresc_uwagi->setMouseTracking(false);
        label_tresc_uwagi->setTabletTracking(false);
        label_tresc_uwagi->setAcceptDrops(false);
        label_tresc_uwagi->setAutoFillBackground(false);
        label_tresc_uwagi->setScaledContents(false);
        label_tresc_uwagi->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_tresc_uwagi->setWordWrap(true);
        label_tresc_uwagi->setOpenExternalLinks(false);

        verticalLayout_10->addWidget(label_tresc_uwagi);


        verticalLayout_11->addLayout(verticalLayout_10);

        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label_Sciezka_do_pliku_z_mapa->setText(QCoreApplication::translate("MainWindow", "\305\232cie\305\274ka do pliku z map\304\205", nullptr));
        label_blad_Sciezka_do_pliku_z_mapa->setText(QCoreApplication::translate("MainWindow", "B\305\202\304\205d!", nullptr));
        label_Wspolzedne_punktu_poczatkowego->setText(QCoreApplication::translate("MainWindow", "Wsp\303\263\305\202\305\274\304\231dne punktu poczatkowego", nullptr));
        label_x_poczatkowy->setText(QCoreApplication::translate("MainWindow", "X", nullptr));
        label_blad_x_poczatkowy->setText(QCoreApplication::translate("MainWindow", "B\305\202\304\205d!", nullptr));
        label_y_poczatkowy->setText(QCoreApplication::translate("MainWindow", "Y", nullptr));
        label_blad_y_poczatkowy->setText(QCoreApplication::translate("MainWindow", "B\305\202\304\205d!", nullptr));
        label_wspolzedne_punktu_koncowego->setText(QCoreApplication::translate("MainWindow", "Wsp\303\263\305\202\305\274\304\231dne punktu ko\305\204cowego", nullptr));
        label_x_koncowy->setText(QCoreApplication::translate("MainWindow", "X", nullptr));
        label_blad_x_koncowy->setText(QCoreApplication::translate("MainWindow", "B\305\202\304\205d!", nullptr));
        label_y_koncowy->setText(QCoreApplication::translate("MainWindow", "Y", nullptr));
        label_blad_y_koncowy->setText(QCoreApplication::translate("MainWindow", "B\305\202\304\205d!", nullptr));
        label_Sciezka_do_zapisu_pliku->setText(QCoreApplication::translate("MainWindow", "\305\232cie\305\274ka do zapisu pliku", nullptr));
        label_blad_Sciezka_do_zapisu_pliku->setText(QCoreApplication::translate("MainWindow", "B\305\202\304\205d!", nullptr));
        pB_Zaladuj_mape->setText(QCoreApplication::translate("MainWindow", "Za\305\202aduj map\304\231", nullptr));
        label_Udalo_sie_zaladowac_mape->setText(QCoreApplication::translate("MainWindow", "Uda\305\202o si\304\231 za\305\202adowa\304\207 map\304\231", nullptr));
        label_Zaladowano_mape_z->setText(QCoreApplication::translate("MainWindow", "Za\305\202adowano map\304\231 z:", nullptr));
        label_pilik_z_ktorego_pobrano->setText(QCoreApplication::translate("MainWindow", "-", nullptr));
        pB_Wyznacz_trase->setText(QCoreApplication::translate("MainWindow", "Wyzncz tras\304\231", nullptr));
        label_Udalo_sie_wyznaczyc_trase->setText(QCoreApplication::translate("MainWindow", "Uda\305\202o si\304\231 wyznaczy\304\207 tras\304\231", nullptr));
        pB_Zapisz_trase->setText(QCoreApplication::translate("MainWindow", "Zapisz tras\304\231", nullptr));
        label_Udalo_sie_zapisac_rozwiazanie->setText(QCoreApplication::translate("MainWindow", "Uda\305\202o si\304\231 zapisa\304\207 rozwi\304\205zanie", nullptr));
        label_Rozwiazanie_zapisano_do->setText(QCoreApplication::translate("MainWindow", "Rozwi\304\205zanie zapisano do:", nullptr));
        label_plik_do_ktorego_zapisano->setText(QCoreApplication::translate("MainWindow", "-", nullptr));
        label_Uwaga->setText(QCoreApplication::translate("MainWindow", "Uwaga!", nullptr));
        label_tresc_uwagi->setText(QCoreApplication::translate("MainWindow", "(1) Napro\305\233ciej b\304\231dzie je\305\274eli badana mapa, b\304\231dzie w pliku w folderze ze zbudowanym programem. (2) Je\305\274eli po nci\305\233ni\304\231ciu przycisku, przy kt\303\263rym\305\233 z p\303\263l tekstowych, powy\305\274ej przycisku wy\305\233wietla si\304\231 \"B\305\202\304\205d!\" w kolorze czarnym, oznacza to, \305\274e pobano b\305\202\304\231dn\304\205 warto\305\233\304\207 i nie mo\305\274na wykona\304\207, \305\274\304\205danego dzia\305\202\304\205nia. Je\305\274eli pod przyciskiem adontacje s\304\205 w kolorze szarym, a nie czarnym, to oznacza, \305\274e nie uda\305\202o si\304\231 wykona\304\207 dzia\305\202ania przycisku. (3) Od razu po w\305\202\304\205czeniu programu przy wszystkich polach tekstowych powinny si\304\231 wy\305\233wietla\304\207 adnotacje o b\305\202\304\231dzie w kolorze czarnym. (4) Informacje ob\305\202\304\231dzie mog\304\205 zmieni\304\207 kolor tylko po wci\305\233ni\304\231ciu przycisku poni\305\274ej. (5) Aby przej\305\233\304\207 do kolejnego kroku, p"
                        "oprzedni musi by\304\207 wykonany poprawnie. (6) Nie mo\305\274na wykona\304\207 kilku polece\305\204 jednocze\305\233nie.", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
